export default function InstanciasPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Instancias y expedientes</h2>
      <p className="text-gray-400">
        Página dedicada a la gestión de instancias y expedientes, con controles de plazos, estados, responsables y
        posibilidad de derivar tareas.
      </p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Módulo de instancias aún por implementar.</p>
      </div>
    </div>
  );
}