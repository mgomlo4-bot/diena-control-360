export default function ImportacionesPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Importaciones de datos</h2>
      <p className="text-gray-400">
        Usa este módulo para cargar datos desde archivos Excel o CSV. El flujo de importación incluye subida de archivo,
        selección de hoja, previsualización, mapeo de columnas y carga en staging para revisión antes de confirmar.
      </p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Funcionalidad de importación en desarrollo.</p>
      </div>
    </div>
  );
}