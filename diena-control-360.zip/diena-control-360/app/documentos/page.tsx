export default function DocumentosPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Documentos</h2>
      <p className="text-gray-400">Sube y asocia documentos a cursos, instancias y tareas. Filtra por categoría y busca por nombre.</p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Gestión documental pendiente de desarrollo.</p>
      </div>
    </div>
  );
}