export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Dashboard</h2>
      <p className="text-gray-400">Aquí aparecerán las tarjetas de indicadores clave y gráficos una vez implementados.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Ejemplos de tarjetas KPI */}
        <div className="bg-background-card p-4 rounded shadow">
          <h3 className="text-lg font-semibold">Cursos totales</h3>
          <p className="text-3xl">0</p>
        </div>
        <div className="bg-background-card p-4 rounded shadow">
          <h3 className="text-lg font-semibold">Cursos activos</h3>
          <p className="text-3xl">0</p>
        </div>
        <div className="bg-background-card p-4 rounded shadow">
          <h3 className="text-lg font-semibold">Hitos vencidos</h3>
          <p className="text-3xl">0</p>
        </div>
      </div>
    </div>
  );
}