export default function CursosPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Cursos</h2>
      <p className="text-gray-400">
        Aquí se mostrará la lista de cursos con filtros por estado, tipo, escuela, responsable y fecha. Se permitirá crear,
        editar y ver los detalles de cada curso.
      </p>
      {/* Tabla de cursos pendiente de implementación */}
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">No hay datos de cursos disponibles en este momento.</p>
      </div>
    </div>
  );
}