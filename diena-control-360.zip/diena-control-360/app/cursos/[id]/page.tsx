import { notFound } from 'next/navigation';

interface Params {
  params: { id: string };
}

export default function CursoDetallePage({ params }: Params) {
  const { id } = params;
  // Para este esqueleto no hay carga de datos real. En una implementación futura se consultará el curso por ID.
  if (!id) {
    notFound();
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Ficha del curso</h2>
      <p className="text-gray-400">Detalles del curso con ID: {id}</p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Esta página mostrará todos los datos del curso, hitos, tareas, instancias y documentos asociados.</p>
      </div>
    </div>
  );
}