export default function CentrosPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Centros y Organismos</h2>
      <p className="text-gray-400">Administra las escuelas, centros docentes, unidades y organismos asociados a los cursos e instancias.</p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Módulo de centros en construcción.</p>
      </div>
    </div>
  );
}