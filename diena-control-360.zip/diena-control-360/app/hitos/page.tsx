export default function HitosPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Hitos</h2>
      <p className="text-gray-400">
        Aquí se listarán los hitos de los cursos, con posibilidad de verlos en tabla o calendario, filtrar por estado de
        hito, curso, responsable y fecha.
      </p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Listado de hitos en construcción.</p>
      </div>
    </div>
  );
}