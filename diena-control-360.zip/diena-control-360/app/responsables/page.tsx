export default function ResponsablesPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Responsables</h2>
      <p className="text-gray-400">Gestiona la lista de personas responsables, sus datos de contacto y su carga de trabajo.</p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Módulo de responsables pendiente de implementación.</p>
      </div>
    </div>
  );
}