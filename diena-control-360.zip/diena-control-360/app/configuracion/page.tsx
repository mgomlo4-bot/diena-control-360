export default function ConfiguracionPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Configuración</h2>
      <p className="text-gray-400">
        Tablas maestras y configuración general de la aplicación. Aquí se podrán editar listas como estados de cursos,
        tipos de curso, categorías de hitos, prioridades de tareas y permisos de usuarios.
      </p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">Módulo de configuración pendiente de desarrollo.</p>
      </div>
    </div>
  );
}