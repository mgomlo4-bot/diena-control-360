import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
      <h2 className="text-3xl font-bold">Bienvenido a DIENA CONTROL 360</h2>
      <p className="max-w-md text-gray-300">
        Esta aplicación sirve para gestionar de forma integral los cursos, hitos, instancias, tareas y más de la Dirección de
        Enseñanza Naval. Utiliza el menú lateral (pendiente de implementación) para navegar por los distintos módulos.
      </p>
      <Link href="/dashboard" className="px-4 py-2 bg-primary-dark rounded text-white hover:bg-primary-light transition">
        Ir al Dashboard
      </Link>
    </div>
  );
}