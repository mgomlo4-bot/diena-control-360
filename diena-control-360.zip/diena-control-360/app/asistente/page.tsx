export default function AsistentePage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Asistente DIENA</h2>
      <p className="text-gray-400">
        Este módulo se prepara para integrar un asistente documental basado en IA. Aquí se podrá conversar con el asistente
        para redactar correos, oficios, contestaciones de instancias, resumir documentos y proponer acciones.
      </p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">La interfaz del asistente aún no está lista.</p>
      </div>
    </div>
  );
}