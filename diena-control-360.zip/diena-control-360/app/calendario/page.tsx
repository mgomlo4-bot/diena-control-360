export default function CalendarioPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Calendario</h2>
      <p className="text-gray-400">
        Un calendario consolidado de hitos, tareas, fechas de instancias y eventos de cursos. Se implementará con
        FullCalendar o similar.
      </p>
      <div className="bg-background-card p-4 rounded shadow">
        <p className="text-gray-400">El calendario se integrará más adelante.</p>
      </div>
    </div>
  );
}